extern unsigned long seivesize;

extern unsigned char seive[];
