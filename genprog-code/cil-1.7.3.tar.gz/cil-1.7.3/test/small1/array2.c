typedef double real, *realptr;
typedef real vector[3], matrix1[3][4];


static void testdata(void )
{
  vector cmr;
  {
    int _i;
    for(_i = 0; _i < 3; _i++)
      cmr[_i] = 0.0;
  }
}


void radiatepiece(int s,int gral,int c, int (*rtval)[26]) {

  s = rtval[2][3];
  
}
