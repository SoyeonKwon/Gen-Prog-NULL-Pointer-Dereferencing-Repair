extern void print(char name[8]);


void show()
{
  char name[8];
  print(name);
}
