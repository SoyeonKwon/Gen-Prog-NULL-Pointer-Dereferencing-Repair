int main() {
	int x = 0;
	return 1 && x == 4;
}
