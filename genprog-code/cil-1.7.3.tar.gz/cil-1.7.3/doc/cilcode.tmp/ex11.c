char *foo = "foo " " plus " " bar ";
