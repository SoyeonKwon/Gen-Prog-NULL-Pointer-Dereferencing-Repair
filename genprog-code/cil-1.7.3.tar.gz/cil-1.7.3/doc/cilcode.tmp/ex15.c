  int foo() {
    int x = 5;
  } 
