 struct { int x; } s;
